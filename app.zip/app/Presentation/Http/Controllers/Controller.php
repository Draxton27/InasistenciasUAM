<?php

namespace App\Presentation\Http\Controllers;

abstract class Controller
{
    //
}
